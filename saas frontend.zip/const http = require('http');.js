const http = require('http');
const url = require('url');

function calculate(operation, num1, num2) {
  num1 = parseFloat(num1);
  num2 = parseFloat(num2);

  switch (operation) {
    case 'add':
      return num1 + num2;
    case 'subtract':
      return num1 - num2;
    case 'multiply':
      return num1 * num2;
    case 'divide':
      if (num2 === 0) {
        return 'Error: Division by zero';
      }
      return num1 / num2;
    default:
      return 'Invalid operation';
  }
}

const server = http.createServer((req, res) => {
  const parsedUrl = url.parse(req.url, true); // Parse query parameters
  const operation = parsedUrl.query.operation;
  const num1 = parsedUrl.query.num1;
  const num2 = parsedUrl.query.num2;

  if (!operation || !num1 || !num2) {
    res.statusCode = 400;
    res.end('Missing required parameters (operation, num1, num2)');
    return;
  }

  const result = calculate(operation, num1, num2);
  res.setHeader('Content-Type', 'text/plain'); // Set response content type
  res.end(result.toString());
});

server.listen(5500, () => {
  console.log('Server listening on port 5500');
});
